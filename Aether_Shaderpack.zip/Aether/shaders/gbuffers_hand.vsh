#version 330 compatibility
out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 vNormal;
void main(){
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    lmcoord = clamp(((gl_TextureMatrix[1]*gl_MultiTexCoord1).xy - 0.0313)*1.067, 0.0, 1.0);
    glcolor = gl_Color;
    vNormal = normalize(gl_NormalMatrix*gl_Normal);
}
